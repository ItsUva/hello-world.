hourly_wage = float(input("Enter the hourly wage: "))
total_regular_hours = float(input("Enter the total regular hours worked: "))
total_overtime_hours = float(input("Enter the total overtime hours worked: "))

regular_pay = hourly_wage * total_regular_hours
overtime_pay = 1.5 * hourly_wage * total_overtime_hours
total_pay = regular_pay + overtime_pay

print(f"The total weekly pay for the employee is: ${total_pay:.2f}")
