income = float(input("Enter the income: "))
tax_rate = float(input("Enter the tax rate (as a decimal): "))

tax = income * tax_rate
rounded_tax = round(tax, 2)

print(f"The calculated tax amount is: {rounded_tax}")
