speed_of_light = 3 * 10**8
seconds_in_a_year = 365 * 24 * 60 * 60

distance_in_light_year = speed_of_light * seconds_in_a_year

print(f"The distance a light beam travels in one light-year is: {distance_in_light_year} meters")
