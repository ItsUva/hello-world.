def newton(number, guess=None):
    guess = number / 2 if guess is None else 0.5 * (guess + number / guess)
    new_guess = 0.5 * (guess + number / guess)

    if abs(new_guess - guess) < 1e-10:
        return new_guess
    else:
        return newton(number, guess=new_guess)

def main():
    print("Newton's Method for Square Root Approximation (Recursive)")
    print("Press Enter/Return key to exit.")

    while True:
        user_input = input("Enter a number: ")

        if not user_input:
            print("Exiting the program.")
            break

        try:
            number = float(user_input)
            if number < 0:
                print("Please enter a non-negative number.")
            else:
                result = newton(number)
                print(f"Square root of {number} is approximately {result:.6f}")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

if __name__ == "__main__":
    main()
