def newton_sqrt(number):
    guess = number / 2

    while True:
        new_guess = 0.5 * (guess + number / guess)
        
        if abs(new_guess - guess) < 1e-10:
            break

        guess = new_guess

    return new_guess

def main():
    print("Square Root Approximation with Newton's Method")
    print("Press Enter/Return key to exit.")

    while True:
        user_input = input("Enter a number: ")

        if not user_input:
            print("Exiting the program.")
            break

        try:
            number = float(user_input)
            if number < 0:
                print("Please enter a non-negative number.")
            else:
                result = newton_sqrt(number)
                print(f"Square root of {number} is approximately {result:.6f}")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

if __name__ == "__main__":
    main()
