import tkinter as tk
from tkinter import ttk

class TemperatureConverter:
    def __init__(self, root):
        self.root = root
        self.root.title('Temperature Converter')

        self.fahrenheit_var = tk.DoubleVar()
        self.celsius_var = tk.DoubleVar()

        self.fahrenheit_var.set(32.0)
        self.celsius_var.set(0.0)

        ttk.Label(root, text='Fahrenheit:').grid(row=0, column=0, padx=10, pady=10)
        ttk.Label(root, text='Celsius:').grid(row=1, column=0, padx=10, pady=10)

        self.fahrenheit_entry = ttk.Entry(root, textvariable=self.fahrenheit_var)
        self.fahrenheit_entry.grid(row=0, column=1, padx=10, pady=10)

        self.celsius_entry = ttk.Entry(root, textvariable=self.celsius_var)
        self.celsius_entry.grid(row=1, column=1, padx=10, pady=10)

        ttk.Button(root, text='>>>>', command=self.convert_to_celsius).grid(row=2, column=0, padx=10, pady=10)
        ttk.Button(root, text='<<<<', command=self.convert_to_fahrenheit).grid(row=2, column=1, padx=10, pady=10)

    def convert_to_celsius(self):
        try:
            fahrenheit_value = float(self.fahrenheit_var.get())
            celsius_value = (fahrenheit_value - 32) * 5.0 / 9.0
            self.celsius_var.set(round(celsius_value, 2))
        except ValueError:
            self.celsius_var.set('Invalid input')

    def convert_to_fahrenheit(self):
        try:
            celsius_value = float(self.celsius_var.get())
            fahrenheit_value = celsius_value * 9.0 / 5.0 + 32
            self.fahrenheit_var.set(round(fahrenheit_value, 2))
        except ValueError:
            self.fahrenheit_var.set('Invalid input')

if __name__ == "__main__":
    root = tk.Tk()
    app = TemperatureConverter(root)
    root.mainloop()
