import tkinter as tk
from tkinter import ttk

def calculate_tax():
    try:
        income = float(income_entry.get())
        dependents = int(dependents_entry.get())

        income_tax = calculate_tax_function(income, dependents)

        result_label.config(text=f'Total Tax: ${income_tax:.2f}')
    except ValueError:
        result_label.config(text='Invalid input. Please enter valid numbers.')

def calculate_tax_function(income, dependents):
    return income * 0.2 - dependents * 1000

root = tk.Tk()
root.title('Tax Calculator')

income_label = ttk.Label(root, text='Gross Income:')
income_label.grid(row=0, column=0, padx=10, pady=10, sticky='E')

income_entry = ttk.Entry(root)
income_entry.grid(row=0, column=1, padx=10, pady=10)

dependents_label = ttk.Label(root, text='Dependents:')
dependents_label.grid(row=1, column=0, padx=10, pady=10, sticky='E')

dependents_entry = ttk.Entry(root)
dependents_entry.grid(row=1, column=1, padx=10, pady=10)

calculate_button = ttk.Button(root, text='Calculate Tax', command=calculate_tax)
calculate_button.grid(row=2, column=0, columnspan=2, pady=10)

result_label = ttk.Label(root, text='')
result_label.grid(row=3, column=0, columnspan=2, pady=10)

root.mainloop()
