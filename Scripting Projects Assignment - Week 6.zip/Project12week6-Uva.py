def process_employee_data(file_content):
    try:
        print("{:<15} {:<15} {:<15}".format("Employee", "Hours Worked", "Wages Paid"))
        print("=" * 45)

        lines = file_content.splitlines()
        for line in lines:
            components = line.strip().split('<')
            last_name = components[3].strip('>')
            hourly_wage = float(components[5].strip('>'))
            hours_worked = float(components[7].strip('>'))
            wages_paid = hourly_wage * hours_worked
            print("{:<15} {:<15.2f} ${:<15.2f}".format(last_name, hours_worked, wages_paid))

    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    sample_input = """<Details Program code<Last_Name<John<Hourly_Wage<15<Hours_Worked<40
<Details Program code<Last_Name<Doe<Hourly_Wage<20<Hours_Worked<30"""

    process_employee_data(sample_input)
