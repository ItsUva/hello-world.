def copy_file():
    source_file_name = input("Enter the name of the source file: ")
    destination_file_name = input("Enter the name of the destination file: ")

    try:
        with open(source_file_name, 'r') as source_file:
            file_contents = source_file.read()
            with open(destination_file_name, 'w') as destination_file:
                destination_file.write(file_contents)

        print(f"Contents of {source_file_name} have been copied to {destination_file_name} successfully.")

    except FileNotFoundError:
        print("One or both of the files does not exist. Please check the file names and try again.")

if __name__ == "__main__":
    copy_file()
