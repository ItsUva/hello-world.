def caesar_decipher(encrypted_text, distance):
    decrypted_text = ""
    for char in encrypted_text:
        if char.isprintable():
            if char.isalpha():
                if char.isupper():
                    decrypted_text += chr((ord(char) - distance - ord('A')) % 26 + ord('A'))
                elif char.islower():
                    decrypted_text += chr((ord(char) - distance - ord('a')) % 26 + ord('a'))
            else:
                decrypted_text += chr((ord(char) - distance) % 128)
        else:
            decrypted_text += char
    return decrypted_text

encrypted_text = input("Enter the encrypted text: ")
distance = int(input("Enter the distance value: "))
plaintext = caesar_decipher(encrypted_text, distance)
print("Decrypted Plaintext:", plaintext)
