def caesar_cipher(plaintext, distance):
    encrypted_text = ""
    for char in plaintext:
        if char.isprintable():
            if char.isalpha():
                if char.isupper():
                    encrypted_text += chr((ord(char) - ord('A') + distance) % 26 + ord('A'))
                elif char.islower():
                    encrypted_text += chr((ord(char) - ord('a') + distance) % 26 + ord('a'))
            else:
                encrypted_text += chr((ord(char) + distance) % 128)
        else:
            encrypted_text += char
    return encrypted_text

plaintext = input("Enter the plaintext: ")
distance = int(input("Enter the distance value: "))
encrypted_text = caesar_cipher(plaintext, distance)
print("Encrypted Text:", encrypted_text)
