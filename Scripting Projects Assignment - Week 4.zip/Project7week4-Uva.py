starting_salary = float(input("Enter the starting salary for teachers: "))
percentage_increase = float(input("Enter the percentage increase per year: "))
num_years = int(input("Enter the number of years in the salary schedule: "))

print(f"\n{'Year':<5}{'Salary':<10}")

for year in range(1, num_years + 1):
    salary = starting_salary * (1 + percentage_increase / 100) ** (year - 1)
    print(f"{year:<5}${salary:.2f}")
