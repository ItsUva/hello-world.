initial_height = float(input("Enter the initial height from which the ball is dropped (in feet): "))
num_bounces = int(input("Enter the number of times the ball is allowed to bounce: "))

total_distance = initial_height

for _ in range(num_bounces):
    total_distance += 0.6 * total_distance

print(f"The total distance traveled by the ball is: {total_distance:.2f} feet")
