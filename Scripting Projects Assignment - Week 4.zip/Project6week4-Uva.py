num_iterations = int(input("Enter the number of iterations for π approximation: "))

pi_approximation = 0

for i in range(num_iterations):
    term = 1 / (2 * i + 1) if i % 2 == 0 else -1 / (2 * i + 1)
    pi_approximation += term

pi_approximation *= 4

print(f"The approximated value of π after {num_iterations} iterations is: {pi_approximation}")
