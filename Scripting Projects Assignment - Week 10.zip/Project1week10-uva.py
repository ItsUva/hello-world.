import turtle
import math

def drawCircle(t, center, radius):
    t.penup()
    t.goto(center)
    t.pendown()

    circumference_distance = 2 * math.pi * radius / 120

    for _ in range(120):
        t.forward(circumference_distance)
        t.left(3)

# Example usage:
drawCircle(turtle.Turtle(), (0, 0), 100)
turtle.done()
