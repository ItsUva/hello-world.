import turtle

def drawFractalLine(t, distance, angle, level):
    if level == 0:
        t.forward(distance)
    else:
        distance /= 3.0
        drawFractalLine(t, distance, angle, level - 1)
        t.left(angle)
        drawFractalLine(t, distance, angle, level - 1)
        t.right(2 * angle)
        drawFractalLine(t, distance, angle, level - 1)
        t.left(angle)
        drawFractalLine(t, distance, angle, level - 1)

def drawKochSnowflake(t, side_length, levels):
    for _ in range(3):
        drawFractalLine(t, side_length, 60, levels)
        t.right(120)

def main():
    my_turtle = turtle.Turtle()
    screen = turtle.Screen()

    my_turtle.speed(0)
    my_turtle.penup()
    my_turtle.goto(-100, -100)
    my_turtle.pendown()

    screen.bgcolor("white")

    drawKochSnowflake(my_turtle, 300, 3)

    turtle.done()

if __name__ == "__main__":
    main()
