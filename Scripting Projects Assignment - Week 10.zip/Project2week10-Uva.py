import turtle
import random

def cCurve(t, x1, y1, x2, y2, level):
    def getRandomColor():
        return (random.random(), random.random(), random.random())

    if level == 0:
        t.color(getRandomColor())
        t.pendown()
        t.goto(x2, y2)
        t.penup()
    else:
        xm = (x1 + x2 + y1 - y2) // 2
        ym = (x2 + y1 + y2 - x1) // 2
        cCurve(t, x1, y1, xm, ym, level - 1)
        t.color(getRandomColor())  # Set random color before drawing each segment
        cCurve(t, xm, ym, x2, y2, level - 1)

def main():
    my_turtle = turtle.Turtle()
    screen = turtle.Screen()

    my_turtle.speed(0)
    my_turtle.penup()
    my_turtle.goto(-300, -300)
    my_turtle.pendown()

    screen.bgcolor("white")

    cCurve(my_turtle, -300, -300, 300, -300, 5)

    turtle.done()

if __name__ == "__main__":
    main()
