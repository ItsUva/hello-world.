def calculate_cube_volume(side):
    volume = side ** 3
    return volume

side1 = 5
result1 = calculate_cube_volume(side1)
print(f"For side = {side1}, the volume of the cube is {result1}.")

side2 = 7.5
result2 = calculate_cube_volume(side2)
print(f"For side = {side2}, the volume of the cube is {result2}.")

