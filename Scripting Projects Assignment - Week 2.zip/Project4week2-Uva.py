def calculate_rectangle_area(length, width):
    return length * width

test_data = [
    (10, 3),
    (7, 13),
    (6, 6)
]

for length, width in test_data:
    area = calculate_rectangle_area(length, width)
    print(f"Area: {area}")
