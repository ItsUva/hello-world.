def calculate_payment_schedule(purchase_price):
    down_payment = purchase_price * 0.10
    balance, month = purchase_price - down_payment, 1

    print(f"{'Month':<8}{'Balance':<15}{'Interest':<15}{'Principal':<15}{'Payment':<15}{'Remaining Balance':<15}")

    while balance > 0:
        interest = balance * 0.12 / 12
        monthly_payment = min(balance * 0.05, balance)
        principal = monthly_payment - interest
        balance -= principal

        print(f"{month:<8}${balance:,.2f}{interest:,.2f}{principal:,.2f}{monthly_payment:,.2f}${balance:,.2f}")
        month += 1

    print("Payment schedule completed.")

def main():
    purchase_price = float(input("Enter the purchase price: $"))
    calculate_payment_schedule(purchase_price)

if __name__ == "__main__":
    main()
