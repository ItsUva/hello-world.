def is_right_triangle(side1, side2, side3):
    sides = [side1, side2, side3]
    sides.sort()
    return sides[0]**2 + sides[1]**2 == sides[2]**2

side1 = float(input("Enter the length of side 1: "))
side2 = float(input("Enter the length of side 2: "))
side3 = float(input("Enter the length of side 3: "))

if is_right_triangle(side1, side2, side3):
    print("It is a right triangle.")
else:
    print("It is not a right triangle.")
