def is_equilateral_triangle(side1, side2, side3):
    return side1 == side2 == side3

side1 = float(input("Enter the length of side 1: "))
side2 = float(input("Enter the length of side 2: "))
side3 = float(input("Enter the length of side 3: "))

if is_equilateral_triangle(side1, side2, side3):
    print("It is an equilateral triangle.")
else:
    print("It is not an equilateral triangle.")
