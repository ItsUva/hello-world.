from collections import Counter

def calculate_mean(numbers):
    if not numbers:
        return 0

    total = sum(numbers)
    count = len(numbers)
    return total / count

def calculate_median(numbers):
    if not numbers:
        return 0

    sorted_numbers = sorted(numbers)
    n = len(sorted_numbers)

    if n % 2 == 1:
        return sorted_numbers[n // 2]
    else:
        mid1 = n // 2 - 1
        mid2 = n // 2
        return (sorted_numbers[mid1] + sorted_numbers[mid2]) / 2

def calculate_mode(numbers):
    if not numbers:
        return 0

    counts = Counter(numbers)
    max_count = max(counts.values())

    mode_values = [num for num, count in counts.items() if count == max_count]

    if len(mode_values) == len(set(numbers)):
        return 0

    return mode_values

def main():
    test_numbers = [1, 2, 3, 4, 4, 5, 5, 5, 6]

    print(f"Mean: {calculate_mean(test_numbers)}")
    print(f"Median: {calculate_median(test_numbers)}")
    print(f"Mode: {calculate_mode(test_numbers)}")

if __name__ == "__main__":
    main()
