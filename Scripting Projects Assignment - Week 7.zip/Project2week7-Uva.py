def read_file(filename):
    try:
        with open(filename, 'r') as file:
            lines = file.readlines()
        return lines
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")
        return None

def main():
    filename = input("Enter the filename: ")

    lines = read_file(filename)

    if lines is not None:
        while True:
            print(f"\nNumber of lines in the file: {len(lines)}")
            print("Enter a line number (1 to the number of lines, 0 to quit): ")

            try:
                line_number = int(input())
                if line_number == 0:
                    print("Exiting the program.")
                    break
                elif 1 <= line_number <= len(lines):
                    print(f"Line {line_number}: {lines[line_number - 1]}")
                else:
                    print("Invalid line number. Please enter a number between 1 and the number of lines.")
            except ValueError:
                print("Invalid input. Please enter a valid number.")

if __name__ == "__main__":
    main()
