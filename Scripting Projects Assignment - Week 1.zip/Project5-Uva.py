def calculate_triangle_area(base, height):
    return 0.5 * base * height

test_data = [
    (5, 7),
    (6, 5),
    (10, 10)
]

for base, height in test_data:
    area = calculate_triangle_area(base, height)
    print(f"Run - Base {base}, Height {height} => Area: {area}")
