import math

def calculate_circle_area(radius):
    return math.pi * radius ** 2

test_data = [7, 6.31, 14.96]

for radius in test_data:
    area = calculate_circle_area(radius)
    print(f"Run - Radius {radius} => Area: {area}")
