Python 3.12.0 (tags/v3.12.0:0fb18b0, Oct  2 2023, 13:03:39) [MSC v.1935 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> length = float(input("Enter the length of the rectangle: "))
Enter the length of the rectangle: 24
>>> width = float(input("Enter the width of the rectangle: "))
Enter the width of the rectangle: 34
>>> area = length * width
>>> print(f"The area of the rectangle is: {area}")
The area of the rectangle is: 816.0
